# termKalens
Terminal Calendar
We're going to make this work.

Calendar will show a Date.
A Date has a Schedule.
A Schedule is an implementation of a Priority Queue that uses the "EventComparator"
An Event is the entry in a Schedule.
